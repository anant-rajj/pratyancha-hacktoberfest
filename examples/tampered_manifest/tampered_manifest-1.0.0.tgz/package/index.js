module.exports = { hello: () => 'world' };
